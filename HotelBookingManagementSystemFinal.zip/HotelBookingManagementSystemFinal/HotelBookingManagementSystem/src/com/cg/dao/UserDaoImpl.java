package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.*;
import com.cg.exception.HotelException;
import com.cg.util.DBUtil;

public class UserDaoImpl implements UserDao
{
	PreparedStatement pst=null;
	Statement st=null;
	Connection con=null;
	ResultSet rs=null;
	
	Logger usrLogger=null;
	
	public UserDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		usrLogger = Logger.getLogger("UserDaoImpl.class");
	}
	
	@Override
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException 
	{
		ArrayList<Hotels> hotelList= new ArrayList<Hotels>();
		Hotels hSearch = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.SEARCH_HOTEL);
			pst.setString(1,city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hSearch=new Hotels(rs.getString("hotel_id"),
						rs.getString("city"),rs.getString("hotel_name"),
						rs.getString("address"),rs.getString("description"),
						rs.getFloat("avg_rate_per_night"),rs.getString("phone_no1"),
						rs.getString("phone_no2"),rs.getString("rating"),
						rs.getString("email"),rs.getString("fax"));
				hotelList.add(hSearch);
			}
		}
		catch (Exception e)
		{
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				throw new HotelException(e.getMessage());
			}
		}
		return hotelList;
	}
	@Override
	public boolean login(User user) throws HotelException
	{

		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.USER_LOGIN);
			pst.setString(1, user.getId());
			pst.setString(2, user.getPassword());
			rs = pst.executeQuery();
			if(rs.next())
			{
				return true;
			}
		} 
		 catch (Exception e)
		{
			throw new HotelException("Some error while logging in" +e.getMessage());
		}
		return false;
	}
	@Override
	public int registerUser(User user) throws HotelException 
	{
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.USER_REGISTER);
			pst.setString(1, user.getId());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getRole());
			pst.setString(4, user.getName());
			pst.setString(5, user.getMobileNumber());
			pst.setString(6, user.getPhoneNumber());
			pst.setString(7, user.getAddress());
			pst.setString(8, user.getEmail());
			usrLogger.log(Level.INFO,"user Registered: "+user);
			dataAdded = pst.executeUpdate();
		}
		 catch (Exception e) 
		{
			 usrLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException("Some error while registration"+e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new HotelException(e.getMessage());
			}
			
		}
		return dataAdded;
	}
	@Override
    public ArrayList<RoomDetails> showRooms(String hotelname)
            throws HotelException 
    {
        ArrayList<RoomDetails>rdetails=new ArrayList<RoomDetails>();
        RoomDetails rooms=new RoomDetails();
        try
        {
            con=DBUtil.getCon();
            pst=con.prepareStatement(QueryMapper.SHOW_ROOMS);
            pst.setString(1,hotelname);
            rs=pst.executeQuery();
            while(rs.next())
            {
                rooms.setId(rs.getString(2));
                rooms.setNumber(rs.getString(3));
                rooms.setType(rs.getString(4));
                rooms.setPerNightRate(rs.getDouble(5));
                rooms.setAvailability(rs.getString(6));
                rdetails.add(rooms);    
            }
        }
        catch (Exception e)
        {
            throw new HotelException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                con.close();
                pst.close();
            } 
            catch (SQLException e) 
            {
                throw new HotelException(e.getMessage());
            }
        }
        return rdetails;
    }
	  
    @Override
    public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) throws
    HotelException
    {
        int numberOfDays = 0;
        double billAmount = 0;
        try 
        {
            con=DBUtil.getCon();
            PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.BILL_QUERY);
            preparedStatement.setString(1,roomId);
            rs=preparedStatement.executeQuery();
            RoomDetails rooms=new RoomDetails();
            while(rs.next())
            {
                rooms.setPerNightRate(rs.getDouble(1));
            }
            double amount=rooms.getPerNightRate();
            numberOfDays=bookTo.getDayOfYear()-bookFrom.getDayOfYear();
            if(numberOfDays<0)
            {
                numberOfDays=365+numberOfDays;
            }
            billAmount=amount*numberOfDays;
        }
        catch (Exception e)
        {
            throw new HotelException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                con.close();
                pst.close();
            } 
            catch (SQLException e) 
            {
                throw new HotelException(e.getMessage());
            }
        }
        return billAmount;
    }

    public int bookHotel(BookingDetails bookingDetails) throws HotelException 
    {
        int id = 0;
        String bid=null;
        try 
        {
            con=DBUtil.getCon();

                    pst = con.prepareStatement(QueryMapper.INSERT_BOOKINGDETAILS);
                    bookingDetails.setId(generateBookingId());
                    pst.setString(1, bookingDetails.getId());
                    pst.setString(2, bookingDetails.getRoomId());
                    pst.setString(3, bookingDetails.getUserId());
                    pst.setDate(4, Date.valueOf(bookingDetails.getBookFrom()));
                    pst.setDate(5, Date.valueOf(bookingDetails.getBookTo()));
                    pst.setInt(6, bookingDetails.getNoOfAdults());
                    pst.setInt(7, bookingDetails.getNoOfChildren());
                    pst.setDouble(8, bookingDetails.getAmount());
                    usrLogger.log(Level.INFO,"Room Booked: "+bookingDetails);
                    id =pst.executeUpdate();
                    bid=bookingDetails.getId();

//            }
        } 
        catch (Exception e) 
        {
        	 usrLogger.error("This is Exception:"+e.getMessage());
            throw new HotelException(e.getMessage());
        }
		return Integer.valueOf(bid);
    }
    public String generateBookingId() throws HotelException
    {
        String generatedVal;
        try 
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(QueryMapper.BOOKING_SEQUENCE);
            rs.next();
            generatedVal=rs.getString(1);
        } 
        catch (Exception e) 
        {
            throw new HotelException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                con.close();
                st.close();
            } 
            catch (SQLException e) 
            {
                throw new HotelException(e.getMessage());
            }
        }
        return generatedVal;
    }

    @Override
    public ArrayList<BookingDetails> getBookingStatus(String booking_id) throws HotelException 
    {
        ArrayList<BookingDetails> bookingList=new ArrayList<BookingDetails>();
        String searchQry="SELECT * FROM BookingDetails where booking_id=?";
        BookingDetails bk;
        try
        {
            con=DBUtil.getCon();
            pst=con.prepareStatement(searchQry);
            pst.setString(1,booking_id);
            rs=pst.executeQuery();
            while(rs.next())
            {
                bk=new BookingDetails (rs.getString("booking_id"),
                        rs.getString("room_id"),rs.getString("user_id"),
                        rs.getDate("booked_from").toLocalDate(),
                        rs.getDate("booked_to").toLocalDate(), 
                        rs.getInt("no_of_adults"),
                        rs.getInt("no_of_children"),rs.getFloat("amount"));
                bookingList.add(bk);
            }
        }
        catch (Exception e)
        {
            throw new HotelException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                con.close();
                pst.close();
            } 
            catch (SQLException e) 
            {
                throw new HotelException(e.getMessage());
            }
        }
        return bookingList;
    }
}
