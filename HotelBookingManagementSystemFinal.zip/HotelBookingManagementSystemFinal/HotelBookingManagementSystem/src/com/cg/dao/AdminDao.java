package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.*;
import com.cg.exception.*;


public interface AdminDao 
{
//******************Hotel Management*****************//
	public int addHotels(Hotels htl) throws HotelException;
	public int updateHtl(Hotels hotel) throws HotelException;
	public int deleteHtl(int htlId) throws HotelException;
	public String generateHotelId() throws HotelException;

//***************Room Management******************//
	public int addRooms(RoomDetails room) throws HotelException;
	public String updateRoom(RoomDetails room) throws HotelException;
	public String deleteRoom(String roomid, String hid) throws HotelException;
//*******************View Reports******************************//
	public ArrayList<Hotels> getAllHotels()throws HotelException;
	public ArrayList<BookingDetails> viewBookingsSpecificDate(LocalDate bookdate) throws HotelException;
	public List<User> guestOfSpecificHotel(String hotelId) throws HotelException;
	public List<BookingDetails> specificHotelBookings(String hotelId)throws HotelException;
}
