package com.cg.bean;

import java.time.LocalDate;

public class BookingDetails {
	private String id;
	private String roomId;
	private String userId;
	private LocalDate bookFrom;
	private LocalDate bookTo;
	private int noOfAdults;
	private int noOfChildren;
	private double amount;

	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", roomId=" + roomId + ", userId=" + userId + ", bookFrom=" + bookFrom
				+ ", bookTo=" + bookTo + ", noOfAdults=" + noOfAdults + ", noOfChildren=" + noOfChildren + ", amount="
				+ amount + "]";
	}

	public BookingDetails(String roomId, String userId, LocalDate bookFrom, LocalDate bookTo, int noOfAdults,
			int noOfChildren) {
		super();
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
	}

	public BookingDetails( String roomId, String userId, LocalDate bookFrom, LocalDate bookTo, int noOfAdults,
			int noOfChildren, double amount) {
		super();
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public BookingDetails(String id, String roomId, String userId, LocalDate bookFrom, LocalDate bookTo, int noOfAdults,
			int noOfChildren, double amount) {
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}
	public BookingDetails(String id, String roomId, String userId, LocalDate bookFrom, LocalDate bookTo, int noOfAdults,
			int noOfChildren) {
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public LocalDate getBookFrom() {
		return bookFrom;
	}

	public void setBookFrom(LocalDate bookFrom) {
		this.bookFrom = bookFrom;
	}

	public LocalDate getBookTo() {
		return bookTo;
	}

	public void setBooTo(LocalDate bookTo) {
		this.bookTo = bookTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
}
}
