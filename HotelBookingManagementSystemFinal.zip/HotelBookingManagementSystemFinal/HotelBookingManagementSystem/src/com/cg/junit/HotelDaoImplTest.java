package com.cg.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.dao.AdminDao;
import com.cg.dao.AdminDaoImpl;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.exception.HotelException;

public class HotelDaoImplTest
{
    static AdminDao aDao=null;
    static UserDao uDao=null;
    static BookingDetails bookDetails=null;
    static Hotels hotel=null;
    static RoomDetails room=null;
    static User user=null;
    static String id="";
    
    @BeforeClass
    public static void beforeClass()
    {
        aDao=new AdminDaoImpl();
        uDao=new UserDaoImpl();
        bookDetails=new BookingDetails();
        hotel= new Hotels();
        room= new RoomDetails();
        user= new User();
        id=hotel.getHotelId();
        
    }
    
    @Test
    public void testAddHotel1() throws HotelException
    {
        Assert.assertEquals(1, aDao.addHotels(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testAddHotel2() throws HotelException
    {
        Assert.assertEquals(1, aDao.addHotels(hotel));
    }
    
    @Test
    public void testAddHotel3() throws HotelException
    {
        Assert.assertEquals(0, aDao.addHotels(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testAddHotel4() throws HotelException
    {
        Assert.assertEquals(0, aDao.addHotels(hotel));
    }
    
    @Test
    public void testAddHotel5() throws HotelException
    {
        Assert.assertNotNull(aDao.addHotels(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testAddHotel6() throws HotelException
    {
        Assert.assertNotNull(aDao.addHotels(hotel));
    }
    
    /*****************************************************/
    
    @Test
    public void testEditHotel1() throws HotelException
    {
        Assert.assertEquals(1, aDao.updateHtl(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testEditHotel2() throws HotelException
    {
        Assert.assertEquals(1, aDao.updateHtl(hotel));
    }
    
    @Test
    public void testEditHotel3() throws HotelException
    {
        Assert.assertEquals(0, aDao.updateHtl(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testEditHotel4() throws HotelException
    {
        Assert.assertEquals(0, aDao.updateHtl(hotel));
    }
    
    @Test
    public void testEditHotel5() throws HotelException
    {
        Assert.assertNotNull(aDao.updateHtl(hotel));
    }
    
    @Test(expected=Exception.class)
    public void testEditHotel6() throws HotelException
    {
        Assert.assertNotNull(aDao.updateHtl(hotel));
    }
    
    //*****************************************************
    
    @Test
    public void testAddRoom1() throws HotelException
    {
        Assert.assertEquals(1, aDao.addRooms(room));
    }
    
    @Test(expected=Exception.class)
    public void testAddRoom2() throws HotelException
    {
        Assert.assertEquals(1, aDao.addRooms(room));
    }
    
    @Test
    public void testAddRoom3() throws HotelException
    {
        Assert.assertEquals(0, aDao.addRooms(room));
    }
    
    @Test(expected=Exception.class)
    public void testAddRoom4() throws HotelException
    {
        Assert.assertEquals(0, aDao.addRooms(room));
    }
    
    @Test
    public void testAddRoom5() throws HotelException
    {
        Assert.assertNotNull(aDao.addRooms(room));
    }
    
    @Test(expected=Exception.class)
    public void testAddRoom6() throws HotelException
    {
        Assert.assertNotNull(aDao.addRooms(room));
    }
    
    //*****************************************************
    
        @Test
        public void testBookRoom1() throws HotelException
        {
            Assert.assertEquals(1, uDao.bookHotel(bookDetails));
        }
        
        @Test(expected=Exception.class)
        public void testBookRoom2() throws HotelException
        {
            Assert.assertEquals(1, uDao.bookHotel(bookDetails));
        }
        
        @Test
        public void testBookRoom3() throws HotelException
        {
            Assert.assertEquals(0, uDao.bookHotel(bookDetails));
        }
        
        @Test(expected=Exception.class)
        public void testBookRoom4() throws HotelException
        {
            Assert.assertEquals(0, uDao.bookHotel(bookDetails));
        }
        
        @Test
        public void testBookRoom5() throws HotelException
        {
            Assert.assertNotNull(uDao.bookHotel(bookDetails));
        }
        
        @Test(expected=Exception.class)
        public void testBookRoom6() throws HotelException
        {
            Assert.assertNotNull(uDao.bookHotel(bookDetails));
        }
}
