package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.exception.HotelException;


public class UserServiceImpl implements UserService
{
	UserDao userdao=null;
	public UserServiceImpl()
	{
		userdao=new UserDaoImpl();
	}

	@Override
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException 
	{
		return userdao.searchAllHotels(city);
	}

	@Override
	public boolean login(User user) throws HotelException
	{
		return userdao.login(user);
	}

	@Override
	public int registerUser(User user) throws HotelException
	{
		return userdao.registerUser(user);
	}

	@Override
	public boolean validateUserName(String uname) throws HotelException 
	{
		String namePattern="[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern, uname))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Only Chars allowed and starts with capital eg.Namrata");
		}

	}

	@Override
	public boolean validateMobNo(String umob) throws HotelException 
	{
		String mobPattern="[7-9][0-9]{9}";
		if(Pattern.matches(mobPattern, umob))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid phone number eg:9563245217");
		}
	}

	@Override
	public boolean validatePhnNo(String uphn) throws HotelException {
		String phnPattern="[2-6][0-9]{7}";
		if(Pattern.matches(phnPattern, uphn))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid phone number eg:25251456");
		}
	}

	@Override
	public boolean validateAddress(String uadd) throws HotelException 
	{
		String addPattern="[A-Z][a-z]{1,19}";
		if(Pattern.matches(addPattern, uadd))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Only Chars allowed and starts with capital eg.Mumbai");
		}

	}

	@Override
	public boolean validateEmail(String umail) throws HotelException
	{
		String mailPattern="[A-Za-z0-9+_.-]+@(.+)$";
		if(Pattern.matches(mailPattern, umail))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid email id eg- abc@gmail.com");
		}
	}

	@Override
	public ArrayList<RoomDetails> showRooms(String hotelname)throws HotelException
	{
		return userdao.showRooms(hotelname); 
	}

	@Override
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) throws HotelException 
	{
		return userdao.generateBill(roomId, bookFrom, bookTo);
	}

	@Override
	public ArrayList<BookingDetails> getBookingStatus(String booking_id)throws HotelException 
	{
		return userdao.getBookingStatus(booking_id);
	}

	@Override
	public int bookHotel(BookingDetails bookingDetails)
			throws HotelException 
	{
		return userdao.bookHotel(bookingDetails);
	}

	@Override
	public boolean validateDate(LocalDate booked_from, LocalDate booked_till) throws HotelException {
		if(booked_till.isAfter(booked_from)){
			return true;
		}
		return false;
	}

}
