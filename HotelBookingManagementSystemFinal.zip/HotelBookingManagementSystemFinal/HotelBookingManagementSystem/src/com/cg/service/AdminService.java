package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.exception.HotelException;

public interface AdminService
{
	public int addHotels(Hotels htl) throws HotelException;
	public int updateHtl(Hotels hotels) throws HotelException;
	public String generateHotelId() throws HotelException;
	public int deleteHtl(int htlId) throws HotelException;
	public boolean validateAdmName(String cName) throws HotelException;
	public boolean validateAdmPass(String adPass) throws HotelException;
	
//************Room Management**************//
	public int addRooms(RoomDetails room)throws HotelException;
	public String updateRoom(RoomDetails room) throws HotelException;
	public String deleteRoom(String roomid, String hid) throws HotelException;
//*********************Reports *************************//
	public ArrayList<Hotels> getAllHotels()throws HotelException;
	public ArrayList<BookingDetails> viewBookingsSpecificDate(LocalDate bookdate) throws HotelException;
	public List<User> guestOfSpecificHotel(String hotelId) throws HotelException;
	public List<BookingDetails> specificHotelBookings(String hotelId)throws HotelException;
//*********************Validations *************************//
	public boolean validateHotelName(String hname)throws HotelException;
	public boolean validateHotelCity(String hcity)throws HotelException;
	public boolean validateHotelAddress(String hadd)throws HotelException;
	public boolean validatePhone1(String ph1)throws HotelException;
	public boolean validatePhone2(String ph2)throws HotelException;
	public boolean validateHotelMailid(String hemail)throws HotelException;
	public boolean validateFax(String fax)throws HotelException;
	public boolean validateRoomId(String rid)throws HotelException;
	public boolean validateRoomNo(String rno)throws HotelException;
	public boolean validateRoomType(String rtype)throws HotelException;

	
}
